package com.cvjpgm.cvjpgm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvJpgmApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvJpgmApplication.class, args);
	}

}
